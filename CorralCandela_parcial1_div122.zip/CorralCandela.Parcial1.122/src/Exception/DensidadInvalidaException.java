
package Exception;

public class DensidadInvalidaException extends RuntimeException{
    private static final String MENSAJE = "Densidad de follaje invalida";

    public DensidadInvalidaException() {
        this(MENSAJE);
    }

    public DensidadInvalidaException(String mensaje) {
        super(mensaje);
    }

    

}
