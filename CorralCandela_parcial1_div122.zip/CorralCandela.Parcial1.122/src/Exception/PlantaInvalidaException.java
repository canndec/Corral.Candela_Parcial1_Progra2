
package Exception;

public class PlantaInvalidaException extends RuntimeException {
   private static final String MENSAJE = "Planta ya ingresada anterioremente"; 

    public PlantaInvalidaException() {
        this(MENSAJE);
    }

    public PlantaInvalidaException(String mensaje) {
        super(mensaje);
    }

   




}
