
package Model;

import Interfaces.Desprendible;
import Interfaces.Podable;

public class Arbol extends Planta implements Podable, Desprendible{
    private int alturaMax;
    private static final int ALTURA_MAX = 100;
    private static final int ALTURA_MIN = 1;

    public Arbol(String nombre, String ubicacionesJardin, String clima,int alturaMax) {
        super(nombre, ubicacionesJardin, clima);
        verificarAltura(alturaMax);
        this.alturaMax = alturaMax;
    }
    
    private void verificarAltura(int alturaMax){
        /**
         * Valida que la altura del arbol no este fuera de rango, lanzara exception en dicho caso
         */
        if (alturaMax < ALTURA_MIN || alturaMax > ALTURA_MAX){
            throw new IllegalArgumentException(); 
        }
    }

    @Override
    public void podar() {
        System.out.println("El arbol "+ getNombre() +" esta siendo podado");
    }

    @Override
    public void desprenderAroma() {
        System.out.println("El arbol "+ getNombre()+" desprende su aroma");
    }

    @Override
    public String getEspecificacion() {
      return "Altura: "+alturaMax;
    }
    
    
    
    
    
    
    
    
    
}
