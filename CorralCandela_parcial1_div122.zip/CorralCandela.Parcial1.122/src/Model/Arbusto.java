
package Model;

import Exception.DensidadInvalidaException;
import Interfaces.Podable;

public class Arbusto extends Planta implements Podable{
    private int densidadFollaje;
    private static final int DENSIDAD_MIN = 1;
    private static final int DENSIDAD_MAX = 10;

    public Arbusto(String nombre, String ubicacionesJardin, String clima,int densidadFollaje) {
        super(nombre, ubicacionesJardin, clima);
        validarDensidadFollaje(densidadFollaje);
        this.densidadFollaje = densidadFollaje;
    }
    private void validarDensidadFollaje(int densidad){
        /**
         * valida que la densidad ingresada no se encuentre fuera de rando en ese caso lanza exception
         */
        if (densidad < DENSIDAD_MIN || densidad > DENSIDAD_MAX){
            throw new DensidadInvalidaException("Densidad de follaje fuera de rango");
        }
    }

    @Override
    public void podar() {
        System.out.println("El arbusto de " + getNombre() +" esta siendo podado");
    }

    @Override
    public String getEspecificacion() {
        return "Densidad de follaje: "+densidadFollaje;
    }
    
    
    
}
