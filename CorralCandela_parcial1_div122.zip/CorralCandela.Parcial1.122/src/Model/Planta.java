
package Model;

import java.util.Objects;

public abstract class Planta {
    private String nombre;
    private String ubicacionesJardin;
    private String clima;

    public Planta(String nombre, String ubicacionesJardin, String clima) {
        this.nombre = nombre;
        this.ubicacionesJardin = ubicacionesJardin;
        this.clima = clima;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacionesJardin() {
        return ubicacionesJardin;
    }

    public String getClima() {
        return clima;
    }
    public abstract String getEspecificacion();
    
    
    //sobre escritura de equals y hashcode
    @Override
    public boolean equals(Object o){
        if(o == null || !(o instanceof Planta p)){
            return false;
        }return this.nombre.equals(p.nombre) && this.ubicacionesJardin.equals(p.ubicacionesJardin);
    }
    @Override
    public int hashCode(){
        return Objects.hash(nombre,ubicacionesJardin);
    }
    
}
