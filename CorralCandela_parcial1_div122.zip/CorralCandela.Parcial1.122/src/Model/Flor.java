
package Model;

import Enum.Temporada;
import Interfaces.Desprendible;

public class Flor extends Planta implements Desprendible{
    private Temporada temporada;

    public Flor(String nombre, String ubicacionesJardin, String clima,Temporada temporada) {
        super(nombre, ubicacionesJardin, clima);
        this.temporada = temporada;
    }

    public Temporada getTemporada(){
        return temporada;
    }
    @Override
    public String getNombre(){
        return super.getNombre();
    }
    @Override
    public String getUbicacionesJardin() {
        return super.getUbicacionesJardin();
    }

    
    @Override
    public void desprenderAroma() {
        System.out.println("La flor "+ getNombre() + " esta desprendiendo su aroma");
    }

    @Override
    public String getEspecificacion() {
        return "Temporada de florecimiento: "+temporada;
    }
    
}
