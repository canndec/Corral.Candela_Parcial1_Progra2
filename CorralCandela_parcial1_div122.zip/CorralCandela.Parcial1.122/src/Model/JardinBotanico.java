
package Model;

import Enum.Temporada;
import Exception.PlantaInvalidaException;
import Interfaces.Podable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class JardinBotanico {
    private String nombre;
    private List<Planta> plantas;

    public JardinBotanico(String nombre) {
        this.nombre = nombre;
        plantas = new LinkedList<>();// ojo
        
    }
    
    public void agregarPlanta(Planta planta){
        /**
         * Agregar una planta a la lista de plantas
         */
        if (planta != null){
            verificarCoincidencias(planta);
            plantas.add(planta);
        }
    }
    
    
    private void verificarCoincidencias(Planta planta){
        /**
         * verifica que la planta que se desea ingresar no este ya registrada con mismo nombre y ubicacion, en el jardin
         */
        if (!plantas.isEmpty()){
            for(Planta p: plantas){
                if(p.getNombre().equals(planta.getNombre()) && 
                        p.getUbicacionesJardin().equals(planta.getUbicacionesJardin())){
                    throw new PlantaInvalidaException("La planta que quiere ingresar ya fue registrada");
                            
                }
            }
        }
    }
    
    public void mostrarPlantas(){
        /**
         * Muestra por consola las plantas que se encuentran en la lista en el jardin
         */
        System.out.println("-- PLANTAS DEL JARDIN BOTANICO "+ nombre +" ---");
        for(Planta p:plantas){
            System.out.println(String.format("%-20s | %-10s | %-10s | %-20s", p.getNombre(), p.getUbicacionesJardin(), p.getClima(), p.getEspecificacion()));
        }
    }
    
    public void podarPlantas(){
        /**
         * En caso de que la planta pueda ser podada lo hace, caso contrario muestra mensaje
         */
        for(Planta planta: plantas){
            if(planta instanceof Podable p){
                p.podar();
            }else{
                System.out.println("No se puede podar una flor");
            }
        }
    }
    
    public ArrayList<Flor> filtrarPorTemporadaFlorecimiento(Temporada temporada){
        /**
         * Crea una lista donde se agregan las flores que cumplan con la condicion y la retorta
         * muestra la informacion de dichas flores
         */
        ArrayList<Flor> floresFiltradas = new ArrayList<>();
        for(Planta planta: plantas){
            if(planta instanceof Flor f){
                if(f.getTemporada()==temporada){
                    floresFiltradas.add(f);
                    System.out.println(f.getNombre() +" - "+f.getUbicacionesJardin()+" - "+f.getEspecificacion()); 
                }
            }
        }return floresFiltradas;
    }
}
