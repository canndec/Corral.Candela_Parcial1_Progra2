// division 122 
package corralcandela.parcial1;

import Enum.Temporada;
import Model.Arbol;
import Model.Arbusto;
import Model.Flor;
import Model.JardinBotanico;

public class CorralCandelaParcial1 {

    public static void main(String[] args) {
        JardinBotanico jardin = new JardinBotanico("Tulipanes");
        
        hardcodearJardin(jardin);
        
        jardin.mostrarPlantas();
        System.out.println("-----------------");
        
        jardin.podarPlantas();
        System.out.println("-----------------");
        
        jardin.filtrarPorTemporadaFlorecimiento(Temporada.INVIERNO);
    }
    private static void hardcodearJardin(JardinBotanico j){
        j.agregarPlanta(new Arbol("Roble","Norte","Ventoso",20));
        //j.agregarPlanta(new Arbol("Jade","Sur","Templado",40));
        j.agregarPlanta(new Arbusto("Jazmin", "Este","Lluvioso",5));
        j.agregarPlanta(new Arbusto("Camelias", "Este","Templado",4));
        j.agregarPlanta(new Flor("Tulipanes","Norte","Frio",Temporada.INVIERNO));
        j.agregarPlanta(new Flor("Margaritas","Este","Calido",Temporada.PRIMAVERA));
    
        
        //j.agregarPlanta(new Arbol("Roble","Norte","Ventoso",20));
        //j.agregarPlanta(new Arbol("Roble","Norte","Ventoso",20));
    
    }
}
