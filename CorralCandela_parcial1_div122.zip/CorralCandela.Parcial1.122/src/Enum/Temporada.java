
package Enum;

public enum Temporada {
    PRIMAVERA,
    VERANO,
    OTOÑO,
    INVIERNO;
}
