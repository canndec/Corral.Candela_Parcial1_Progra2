
package Interfaces;

public interface Desprendible {
    void desprenderAroma();
}
